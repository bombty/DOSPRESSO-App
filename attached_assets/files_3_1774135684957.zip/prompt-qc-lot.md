## QC + Lot Tracking System — Full Implementation

### Context
QC (Quality Control) and lot traceability system for DOSPRESSO factory.
Design document exists at `.local/reports/QC-LOT-TRACKING-PLAN.md` — READ IT FIRST.
This sprint implements the full system: DB tables, API endpoints, kiosk integration, dashboard widget.

Read ALL skills + the QC plan document:
- .agents/skills/dospresso-architecture/SKILL.md
- .agents/skills/dospresso-quality-gate/SKILL.md
- .local/reports/QC-LOT-TRACKING-PLAN.md

### CRITICAL RULES
- users.id is VARCHAR (UUID), Turkish UI
- Do NOT touch localAuth.ts, vite.ts, vite.config.ts, package.json, drizzle.config.ts
- Do NOT break existing factory kiosk or production flow
- Use existing auth middleware (isAuthenticated)
- Follow existing Drizzle ORM patterns in the codebase

---

## STEP 0: INVESTIGATE EXISTING FACTORY SYSTEM

```bash
echo "═══ QC INVESTIGATION ═══"

# Existing factory tables
echo "--- Factory tables ---"
echo "SELECT table_name FROM information_schema.tables WHERE table_name LIKE 'factory%' ORDER BY table_name;" | psql

# Production outputs (where QC attaches)
echo "--- factory_production_outputs columns ---"
echo "SELECT column_name, data_type FROM information_schema.columns WHERE table_name='factory_production_outputs' ORDER BY ordinal_position;" | psql

# Existing quality tables?
echo "--- Quality tables ---"
echo "SELECT table_name FROM information_schema.tables WHERE table_name LIKE '%quality%' OR table_name LIKE '%qc%' OR table_name LIKE '%inspection%' OR table_name LIKE '%lot%';" | psql

# Factory products
echo "SELECT id, name, category FROM factory_products WHERE is_active = true LIMIT 15;" | psql

# Factory stations
echo "SELECT id, name, code, product_type_id FROM factory_stations WHERE is_active = true;" | psql

# Existing factory routes
grep -n "router\.\(get\|post\|patch\|delete\)" server/routes/factory.ts | head -30

# Shipment system?
echo "SELECT table_name FROM information_schema.tables WHERE table_name LIKE '%shipment%' OR table_name LIKE '%sevkiyat%';" | psql

# How does kiosk.tsx handle production entry?
grep -n "production\|uretim\|Üretim" client/src/pages/fabrika/kiosk.tsx | head -15

# Existing schema pattern for creating tables
grep -n "export const factory" shared/schema.ts | head -10
```

Report findings before implementing.

---

## PART 1: DATABASE TABLES

Add to shared/schema.ts (follow existing pattern):

### 1A: qc_assignments (weekly QC person assignment)
```typescript
export const qcAssignments = pgTable("qc_assignments", {
  id: serial("id").primaryKey(),
  assignedUserId: varchar("assigned_user_id", { length: 36 }).notNull().references(() => users.id),
  assignedByUserId: varchar("assigned_by_user_id", { length: 36 }).notNull().references(() => users.id),
  weekStart: date("week_start").notNull(),
  weekEnd: date("week_end").notNull(),
  status: varchar("status", { length: 20 }).default("active"), // active, completed
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
```

### 1B: production_lots (lot numbers for traceability)
```typescript
export const productionLots = pgTable("production_lots", {
  id: serial("id").primaryKey(),
  lotNumber: varchar("lot_number", { length: 50 }).notNull().unique(), // LOT-YYYYMMDD-XXX
  productionDate: date("production_date").notNull(),
  productId: integer("product_id").references(() => factoryProducts.id),
  stationId: integer("station_id").references(() => factoryStations.id),
  producerUserId: varchar("producer_user_id", { length: 36 }).references(() => users.id),
  quantity: integer("quantity").default(0),
  unit: varchar("unit", { length: 20 }).default("adet"),
  batchSize: integer("batch_size"), // how many in this batch
  productionOutputId: integer("production_output_id"), // link to factory_production_outputs if exists
  qcStatus: varchar("qc_status", { length: 20 }).default("pending"), // pending, approved, rejected, conditional
  qcInspectionId: integer("qc_inspection_id"),
  shipmentId: integer("shipment_id"),
  destinationBranchId: integer("destination_branch_id").references(() => branches.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});
```

### 1C: qc_inspections (quality control records)
```typescript
export const qcInspections = pgTable("qc_inspections", {
  id: serial("id").primaryKey(),
  assignmentId: integer("assignment_id").references(() => qcAssignments.id),
  inspectorUserId: varchar("inspector_user_id", { length: 36 }).notNull().references(() => users.id),
  lotId: integer("lot_id").references(() => productionLots.id),
  lotNumber: varchar("lot_number", { length: 50 }),
  productId: integer("product_id").references(() => factoryProducts.id),
  stationId: integer("station_id").references(() => factoryStations.id),
  producerUserId: varchar("producer_user_id", { length: 36 }).references(() => users.id),
  
  // Quality checks
  visualCheck: varchar("visual_check", { length: 20 }).default("na"), // passed, failed, na
  weightCheck: varchar("weight_check", { length: 20 }).default("na"),
  packagingCheck: varchar("packaging_check", { length: 20 }).default("na"),
  temperatureCheck: varchar("temperature_check", { length: 20 }).default("na"),
  temperatureValue: real("temperature_value"), // actual reading
  allergenCheck: boolean("allergen_check").default(false),
  haccpCompliant: boolean("haccp_compliant").default(false),
  
  // Overall result
  overallResult: varchar("overall_result", { length: 20 }).default("pending"), // approved, rejected, conditional
  inspectorNotes: text("inspector_notes"),
  rejectionReason: text("rejection_reason"),
  
  // Timestamps
  inspectedAt: timestamp("inspected_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});
```

### 1D: Run migration
```bash
npx drizzle-kit push
# or whatever migration command the project uses
grep -n "drizzle-kit\|migrate" package.json | head -5
```

---

## PART 2: LOT NUMBER GENERATOR

Create utility: `server/utils/lot-number.ts`

```typescript
// Format: LOT-YYYYMMDD-XXX (sequential per day)
// Example: LOT-20260326-001, LOT-20260326-002

export async function generateLotNumber(db: any, date: Date): Promise<string> {
  const dateStr = date.toISOString().split('T')[0].replace(/-/g, '');
  const prefix = `LOT-${dateStr}-`;
  
  // Find highest lot number for this date
  const existing = await db.select({ lotNumber: productionLots.lotNumber })
    .from(productionLots)
    .where(like(productionLots.lotNumber, `${prefix}%`))
    .orderBy(desc(productionLots.lotNumber))
    .limit(1);
  
  let nextNum = 1;
  if (existing.length > 0) {
    const lastNum = parseInt(existing[0].lotNumber.split('-').pop() || '0');
    nextNum = lastNum + 1;
  }
  
  return `${prefix}${nextNum.toString().padStart(3, '0')}`;
}
```

---

## PART 3: API ENDPOINTS

Create `server/routes/qc.ts` (new route file):

```typescript
// === QC ASSIGNMENTS ===

// GET /api/factory/qc/current-assignment — this week's QC person
// GET /api/factory/qc/assignments — all QC assignments (paginated)
// POST /api/factory/qc/assignments — create new assignment (HQ/admin only)
// PATCH /api/factory/qc/assignments/:id — update assignment

// === LOT MANAGEMENT ===

// GET /api/factory/lots — list lots (filter: date, product, status, branch)
// GET /api/factory/lots/:lotNumber — lot detail + full trace chain
// GET /api/factory/lots/:lotNumber/trace — reverse trace: branch → shipment → QC → production → person
// POST /api/factory/lots — auto-create lot when production is recorded

// === QC INSPECTIONS ===

// GET /api/factory/qc/pending — productions awaiting QC
// GET /api/factory/qc/inspections — completed inspections (paginated)
// POST /api/factory/qc/inspections — create inspection record
// GET /api/factory/qc/inspections/:id — inspection detail

// === DASHBOARD ===

// GET /api/factory/qc/stats — today's QC stats (inspected, pending, pass rate)
```

### Key endpoint details:

**POST /api/factory/qc/inspections:**
```typescript
// Body:
{
  lotId: number,          // which lot
  visualCheck: "passed",  // passed | failed | na
  weightCheck: "passed",
  packagingCheck: "passed",
  temperatureCheck: "passed",
  temperatureValue: 4.2,  // optional actual reading
  allergenCheck: true,
  haccpCompliant: true,
  overallResult: "approved", // approved | rejected | conditional
  inspectorNotes: "Görsel kontrol OK, ambalaj sağlam",
  rejectionReason: null
}

// On save:
// 1. Create qc_inspection record
// 2. Update production_lots.qc_status = overallResult
// 3. Update production_lots.qc_inspection_id = new inspection id
// 4. If rejected: create notification to factory_mudur
```

**GET /api/factory/lots/:lotNumber/trace:**
```typescript
// Returns full traceability chain:
{
  lot: { lotNumber, productionDate, quantity, ... },
  product: { name, category },
  station: { name, code },
  producer: { firstName, lastName, role },
  qcInspection: { inspectorName, result, date, checks... },
  shipment: { shipmentDate, destinationBranch, ... } || null,
  branch: { name, receivedDate } || null,
  timeline: [
    { event: "Üretim", date: "...", by: "Fatma A.", detail: "24 adet" },
    { event: "QC Kontrol", date: "...", by: "Ayşe Y.", detail: "Onaylandı" },
    { event: "Sevkiyat", date: "...", detail: "Işıklar şubesine" },
  ]
}
```

### Register routes:
```bash
# Find where routes are registered
grep -n "factory\|import.*routes" server/index.ts | head -10
```

Add: `app.use(qcRoutes);` in server/index.ts

---

## PART 4: AUTO-LOT CREATION

When production is recorded (existing endpoint), auto-create a lot:

```bash
# Find production recording endpoint
grep -n "production.*output\|record.*production\|POST.*production" server/routes/factory.ts | head -10
```

Add lot creation to existing production recording:
```typescript
// After production output is saved:
const lotNumber = await generateLotNumber(db, new Date());
await db.insert(productionLots).values({
  lotNumber,
  productionDate: new Date().toISOString().split('T')[0],
  productId: output.productId,
  stationId: output.stationId,
  producerUserId: output.userId,
  quantity: output.quantity,
  productionOutputId: output.id,
  qcStatus: 'pending',
});
```

---

## PART 5: FACTORY KIOSK — QC BUTTON

Add QC mode to the factory kiosk:

```bash
# Check kiosk structure
grep -n "step\|screen\|view\|mode" client/src/pages/fabrika/kiosk.tsx | head -20
```

### On select-user screen (right sidebar):
Add "QC Kontrol" button below stations:
```typescript
// Only visible if current week has a QC assignment
// Button: "QC: [Assigned Person Name]"
// Click → QC person enters their PIN → enters QC mode
```

### QC Mode screens:
1. **QC Pending List:** Shows lots awaiting inspection (sorted by oldest first)
2. **QC Inspection Form:** For selected lot:
   - Lot number + product name + producer name + quantity (read-only header)
   - Visual check: ✓ / ✗ toggle
   - Weight check: ✓ / ✗ toggle
   - Packaging check: ✓ / ✗ toggle
   - Temperature check: ✓ / ✗ toggle + number input for actual value
   - Allergen check: ✓ / ✗ toggle
   - HACCP compliant: ✓ / ✗ toggle
   - Notes: text area
   - Overall: "Onayla" (green) / "Reddet" (red) / "Koşullu Onayla" (amber)
3. **QC Result:** Confirmation + back to pending list

### Design:
- Same kiosk dark theme
- Large touch-friendly toggles (factory tablets)
- Green = passed, Red = failed, Gray = N/A

---

## PART 6: QC MANAGEMENT PAGE

Create `client/src/pages/fabrika/qc-yonetimi.tsx`:

Tabs:
1. **Bu Hafta:** Current QC assignment + pending inspections count + today's stats
2. **Kontroller:** List of all inspections (filter by date, product, result)
3. **Lot Takip:** Search by lot number → full trace chain
4. **Atamalar:** QC assignment history + create new assignment

### Lot trace view:
- Timeline visualization: Üretim → QC → Sevkiyat → Şube
- Each step shows: who, when, what, result
- Color coded: green = OK, red = failed, gray = pending

### Add to sidebar:
```bash
grep -n "fabrika\|factory" server/menu-service.ts | head -10
```

Add "QC Yönetimi" menu item for: admin, fabrika_mudur, gida_muhendisi, kalite_kontrol roles.

---

## PART 7: MR. DOBODY QC SKILL

```bash
# Find existing skills
ls server/agent/skills/ | head -10
```

Create `server/agent/skills/qc-tracker.ts`:

```typescript
// Triggers:
// - "5 lot hâlâ QC bekliyor" (daily check)
// - "Bugün 2 lot reddedildi — incelenmeli" (on rejection)
// - "Bu hafta QC sorumlusu atanmadı" (weekly check)
// - "Cheesecake hattında fire oranı %5 — kalite sorunu olabilir" (trend detection)

// Target roles: gida_muhendisi, fabrika_mudur, kalite_kontrol, admin
// Severity: critical if rejection > 3/day, warning if pending > 10
```

---

## DO NOT TOUCH:
- localAuth.ts, vite.ts, vite.config.ts, package.json
- Existing production recording logic (only ADD lot creation after it)
- Scoring services
- Existing kiosk screens (only ADD QC mode)

## Testing:
1. Tables created: qc_assignments, production_lots, qc_inspections
2. GET /api/factory/qc/current-assignment → returns this week's QC person (or null)
3. POST /api/factory/qc/assignments → creates assignment (admin only)
4. Production recording → auto-creates lot with LOT-YYYYMMDD-XXX number
5. GET /api/factory/qc/pending → lists lots with qc_status='pending'
6. POST /api/factory/qc/inspections → creates inspection, updates lot status
7. GET /api/factory/lots/LOT-20260322-001/trace → returns full chain
8. Factory kiosk: QC button visible on select-user screen
9. QC mode: pending list → inspection form → result
10. QC management page loads with 4 tabs
11. Mr. Dobody QC skill registered
12. Sidebar: QC Yönetimi visible for factory roles
13. No existing features broken

## After:
1. Report: tables created + column counts
2. Report: endpoints created (list all)
3. Report: lot number format working?
4. Report: kiosk QC mode — screens implemented
5. Report: QC management page route
