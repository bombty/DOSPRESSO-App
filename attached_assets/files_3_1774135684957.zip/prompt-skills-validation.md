## Skill Dosyaları Güncelleme + Final Lansman Doğrulama

### Context
After all the sprints, the DOSPRESSO agent skill files are outdated.
Update them to reflect current system state. Also run final E2E validation.

Read current skills:
- .agents/skills/dospresso-architecture/SKILL.md
- .agents/skills/dospresso-quality-gate/SKILL.md
- .agents/skills/dospresso-debug-guide/SKILL.md

### CRITICAL RULES
- Only modify files in .agents/skills/ directory
- Do NOT touch any application code
- Do NOT touch localAuth.ts, vite.ts, vite.config.ts, package.json

---

## PART 1: UPDATE ARCHITECTURE SKILL

The architecture skill needs updates for:

```bash
echo "═══ SKILL UPDATE INVESTIGATION ═══"

# Current skill content
wc -l .agents/skills/dospresso-architecture/SKILL.md

# New tables added (QC, lots, etc.)
echo "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';" | psql

# New routes
find server/routes -name "*.ts" | wc -l
grep -c "router\.\(get\|post\|patch\|delete\)" server/routes/*.ts | sort -t: -k2 -rn | head -10

# New services
find server/services -name "*.ts" | sort

# New pages
find client/src/pages -name "*.tsx" | wc -l

# New components
find client/src/components/mission-control -name "*.tsx" 2>/dev/null | wc -l

# Current user count
echo "SELECT count(*) FROM users WHERE is_active = true;" | psql

# Current branch count
echo "SELECT count(*) FROM branches WHERE is_active = true;" | psql

# Module flags
echo "SELECT count(*) FROM module_flags WHERE deleted_at IS NULL;" | psql
```

### Update these sections:

1. **Platform stats:** Update table count, endpoint count, page count, user count
2. **New modules:** Add QC system, lot tracking, Widget Studio, Mission Control dashboard
3. **New tables:** qc_assignments, production_lots, qc_inspections, dashboard_layouts, user_dashboard_prefs, employee_documents, disciplinary_records
4. **New services:** payroll-calculation-service, shift-scheduler enhancements
5. **New features:** Dashboard toggle, Mr. Dobody collapsible panel, sparkline KPIs
6. **Updated scoring:** Note that PDKS→Payroll pipeline now exists
7. **File structure:** Update if misc.ts was split, schema.ts was modularized

### Consider splitting the architecture skill (349 lines → max 250):
- `dospresso-architecture/SKILL.md` → Core architecture, stack, auth, RBAC
- `dospresso-modules/SKILL.md` → Module details, new systems, feature registry
- Or keep as one but trim redundant sections

---

## PART 2: UPDATE QUALITY GATE SKILL

Add new checks for:
- Mission Control components follow design system
- QC tables have proper indexes
- Payroll calculations use parameterized values (not hardcoded)
- Dashboard layouts JSON schema validation
- Widget configs have sensible defaults

---

## PART 3: UPDATE DEBUG GUIDE

Add new debug sections for:
- Dashboard layout not loading → check user pref + system default
- Mr. Dobody panel stuck → check localStorage 'dobody-panel-expanded'
- QC inspection not saving → check lot exists + inspector assignment
- Payroll calculation mismatch → check cumulative tax base
- Widget Studio drag-drop not working → check dnd-kit or native drag events

---

## PART 4: CREATE NEW MODULE GUIDE SKILL

Create `.agents/skills/dospresso-module-guide/SKILL.md`:

This is the "yeni modül ekleme adımları" skill that was identified as missing in the skill audit.

Content:
```markdown
# DOSPRESSO — Yeni Modül Ekleme Rehberi

## Adım 1: Veritabanı
- shared/schema.ts (veya schema/ alt dosyası) içinde tablo tanımla
- drizzle-kit push ile migrate et
- Index ekle (en az: primary key + foreign keys + en çok sorgulanan alan)

## Adım 2: Backend Route
- server/routes/yeni-modul.ts oluştur
- isAuthenticated middleware ekle
- Rol kontrolü: RBAC middleware veya inline check
- server/index.ts'te register et

## Adım 3: Frontend Sayfa
- client/src/pages/yeni-modul.tsx oluştur
- useQuery ile veri çek
- Tailwind + shadcn/ui ile UI oluştur
- client/src/App.tsx'te route ekle

## Adım 4: Sidebar Erişimi
- server/menu-service.ts → SIDEBAR_ALLOWED_ITEMS'a ekle
- İlgili rollere erişim ver

## Adım 5: Module Flag
- module_flags tablosuna kayıt ekle
- flag_behavior: 'always_on' veya 'toggleable'

## Adım 6: Mr. Dobody Entegrasyonu
- server/agent/skills/ altına skill ekle
- system-completeness-service.ts'e gap kontrolü ekle

## Adım 7: Test
- Quality gate checklist'i uygula
- Auth zinciri doğrula
- Türkçe UI kontrol
- Dark mode kontrol
- Mobile responsive kontrol
```

---

## PART 5: FINAL E2E VALIDATION

Update and run the launch validation script:

```bash
# Update existing validation script
cat server/scripts/launch-validation.ts | head -20

# Or create enhanced version
```

### Enhanced validation checks:

```typescript
// === EXISTING CHECKS (from before) ===
// DB core tables, branch staff, passwords, PINs, API health, module flags

// === NEW CHECKS ===

// Dashboard system
// - dashboard_layout column exists on users table
// - ai_system_config has default_dashboard_layout entry
// - Mission Control components exist (file check)

// QC system (if implemented)
// - qc_assignments table exists
// - production_lots table exists
// - qc_inspections table exists
// - QC API endpoints respond

// Payroll system
// - 2026 parameters active
// - All salary_scales >= minimum wage
// - payroll-calculation-service exists (file check)

// Code health
// - misc.ts < 2000 lines (was 13K, target < 500 but be realistic)
// - No console.log in client code
// - Server console.log < 100

// Security
// - No passwords in console.log
// - All admin endpoints require auth
// - CORS properly configured

// Data integrity
// - No orphaned records (users without branches)
// - No duplicate usernames
// - All branch IDs referenced in users exist in branches table

// Feature flags
// - akademi flag is always_on
// - All critical modules enabled

// Print: READY / CONDITIONAL / NOT READY
```

Run the validation:
```bash
npx tsx server/scripts/launch-validation.ts
```

---

## Testing:
1. Architecture skill reflects current system state
2. Quality gate has new checks
3. Debug guide has new scenarios
4. Module guide skill created
5. Validation script runs and passes

## After:
1. Report: skill file sizes (before/after)
2. Report: validation results (PASS/FAIL/WARN)
3. Report: any critical issues found in validation
4. Report: launch readiness verdict
